package com.dev3l.hello_world.test;

import org.junit.Assert;
import org.junit.Test;

public class ExampleTest {
	@Test
	public void exampleTest() {
		Assert.assertTrue(true);
	}
}
